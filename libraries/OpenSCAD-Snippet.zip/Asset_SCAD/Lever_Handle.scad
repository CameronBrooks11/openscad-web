module Lever_Handle(){

    color("white")
       rotate([90,0,0])  
       translate([0,0,0])
       cylinder(30,2,2, $fn = 30, center = true); 
      
     
    color("gray")
    translate([-1,14,-1])
    rotate([90,0,0])
    linear_extrude(3, scale = 1, center = true)
    polygon(points=[[0,-3],[2,-3],[5,-1],[5,0],[5,3],[2,5],[0,5]]);


    color("gray")
    translate([-1,14,1])
    rotate([90,180,0])
    linear_extrude(3, scale = 1, center = true)
    polygon(points=[[0,-3],[2,-2],[5,-1],[15,0],[15,3],[2,4],[0,5]]);

}

Lever_Handle();

// Written by Nicolì Angelo (Gengio) 2024: 
// MIT License

//Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

//The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

